## Colorize Windows

These packages are used for colorize on Windows and contributed by mattn.jp@gmail.com

  * go-colorable: <https://github.com/mattn/go-colorable>
  * go-isatty: <https://github.com/mattn/go-isatty>
