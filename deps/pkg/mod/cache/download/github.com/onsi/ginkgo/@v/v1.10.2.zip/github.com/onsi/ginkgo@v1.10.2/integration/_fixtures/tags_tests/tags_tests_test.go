package tags_tests_test

import (
	. "github.com/onsi/ginkgo"
)

var _ = Describe("TagsTests", func() {
	It("should have a test", func() {

	})
})
