/*
Package pg implements a PostgreSQL client.
*/
package pg
